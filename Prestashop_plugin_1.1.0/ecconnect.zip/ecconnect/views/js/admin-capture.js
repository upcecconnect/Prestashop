document.addEventListener('DOMContentLoaded', function () {
  var form = document.getElementById('ecommconnect-capture-form');
  if (!form) return;

  function showMsg(html, cls) {
    var box = form.querySelector('.ecommconnect-message');
    if (box) {
      box.innerHTML = '<div class="alert ' + (cls || 'alert-info') + '">' + html + '</div>';
    }
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();

    var orderId = form.querySelector('[name="order_id"]').value;
    var amount  = form.querySelector('[name="amount"]').value;
    var max     = parseFloat(form.querySelector('[name="amount"]').getAttribute('max') || '0');

    if (isNaN(amount) || parseFloat(amount) < 1) {
      showMsg('Total amount must be a number and at least 1.', 'alert-danger');
      return;
    }
    if (parseFloat(amount) > max) {
      showMsg('Total amount cannot exceed the order total of ' + max + '.', 'alert-danger');
      return;
    }

    var data = new FormData();
    data.append('ajax', '1');
    data.append('action', 'capture');
    data.append('order_id', orderId);
    data.append('amount', amount);

    fetch(ecconnect_capture_ajax, {
      method: 'POST',
      credentials: 'same-origin',
      body: data
    })
      .then(r => r.json())
      .then(res => {
        if (res && res.success) {
          if (res.data && res.data.success) {
            alert(res.data.message || 'Capture success');
            location.reload();
          } else {
            if (res.data && res.data.parsed) {
              var list = Object.entries(res.data.parsed).map(function([k,v]) {
                return '<li><strong>'+k+'</strong>: '+v+'</li>';
              }).join('');
              showMsg('<ul style="margin-left:20px">'+list+'</ul>', 'alert-danger');
            } else {
              showMsg((res.data && res.data.message) || 'Error', 'alert-danger');
            }
          }
        } else {
          showMsg('Unexpected response', 'alert-danger');
        }
      })
      .catch(err => {
        showMsg('Request failed: ' + err, 'alert-danger');
      });
  });
});
