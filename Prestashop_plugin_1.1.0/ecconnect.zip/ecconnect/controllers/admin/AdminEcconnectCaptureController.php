<?php

use PrestaShop\PrestaShop\Adapter\SymfonyContainer;

class AdminEcconnectCaptureController extends ModuleAdminController
{
    public function __construct()
    {
        parent::__construct();
        $this->bootstrap = true;
        $this->ajax = true;

        $this->display = 'ajax';
    }

    public function init()
    {
        parent::init();

        if (Tools::getValue('ajax')) {
            $this->tabAccess = ['view' => 1, 'add' => 1, 'edit' => 1, 'delete' => 1];
        }
    }

    public function postProcess()
    {
        if (Tools::getValue('ajax') && Tools::getValue('action') === 'capture') {
            $this->ajaxProcessCapture();

            return;
        }
        parent::postProcess();
    }

    protected function ajaxProcessCapture()
    {
        if (!$this->context->employee || !$this->context->employee->isLoggedBack()) {
            $this->renderJson([
                'success' => true,
                'data' => [
                    'error' => true,
                    'message' => 'Not authorized',
                ],
            ]);
        }

        $orderId = (int)Tools::getValue('order_id');
        $amount = (float)Tools::getValue('amount');

        if ($orderId <= 0 || $amount <= 0) {
            $this->renderJson([
                'success' => true,
                'data' => [
                    'error' => true,
                    'message' => 'Order ID or amount is invalid',
                ],
            ]);
        }

        $order = new Order($orderId);
        if (!Validate::isLoadedObject($order)) {
            $this->renderJson([
                'success' => true,
                'data' => [
                    'error' => true,
                    'message' => 'Order not found',
                ],
            ]);
        }

        if ($order->module !== $this->module->name) {
            $this->renderJson([
                'success' => true,
                'data' => [
                    'error' => true,
                    'message' => 'Payment method mismatch',
                ],
            ]);
        }

        $targetStateId = (int)Configuration::get('ECCONNECT_PREAUTH_STATUS_ID') ? : 17;
        if ((int)$order->current_state !== $targetStateId) {
            $this->renderJson([
                'success' => true,
                'data' => [
                    'error' => true,
                    'message' => 'Order is not in pre-authorization status',
                ],
            ]);
        }

        $orderTotal = (float)$order->getOrdersTotalPaid();
        if ($amount > $orderTotal) {
            $this->renderJson([
                'success' => true,
                'data' => [
                    'error' => true,
                    'message' => 'Amount cannot exceed order total: ' . $orderTotal,
                ],
            ]);
        }

        $minor = (int)round($amount * 100);

        $postData = $this->module->getCaptureFormData($order, $minor);

        $isTestMode = (bool)Configuration::get('ECCONNECT_TEST_MODE');
        $url = $isTestMode ?
            rtrim((string)Configuration::get('ECCONNECT_GATEWAY_DOMAIN_TEST'), '/') . '/go/capture' :
            rtrim((string)Configuration::get('ECCONNECT_GATEWAY_DOMAIN'), '/') . '/go/capture';

        $response = $this->httpPostForm($url, $postData, 30);

        if ($response['error']) {
            $this->renderJson([
                'success' => true,
                'data' => [
                    'error' => true,
                    'message' => 'Запит не відбувся: ' . $response['message'],
                ],
            ]);
        }

        $parsed = $this->parseUpcPlainResponse($response['body']);

        if (isset($parsed['TranCode']) && $parsed['TranCode'] === '000') {
            $successState = (int)Configuration::get('PS_OS_PAYMENT');
            if ($successState > 0) {
                $order->setCurrentState($successState);
            }
            $order->payment = 'Captured via UPC Gateway';
            $order->save();

            $this->renderJson([
                'success' => true,
                'data' => [
                    'success' => true,
                    'message' => 'Capture success. Order moved to Processing/Payment.',
                ],
            ]);
        }

        $this->renderJson([
            'success' => true,
            'data' => [
                'error' => true,
                'message' => 'Capture failed',
                'parsed' => $parsed,
                'postData' => $postData,
            ],
        ]);
    }

    protected function httpPostForm(string $url, array $fields, int $timeout = 30): array
    {
        $ch = curl_init($url);
        if (!$ch) {
            return ['error' => true, 'message' => 'cURL init failed', 'body' => ''];
        }
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($fields),
            CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
            CURLOPT_TIMEOUT => $timeout,
        ]);
        $body = curl_exec($ch);
        if ($body === false) {
            $err = curl_error($ch);
            curl_close($ch);

            return ['error' => true, 'message' => $err, 'body' => ''];
        }
        curl_close($ch);

        return ['error' => false, 'message' => '', 'body' => (string)$body];
    }

    protected function parseUpcPlainResponse(string $html): array
    {
        if (preg_match('/<p>(.*?)<\/p>/s', $html, $m)) {
            $lines = preg_split('/\r?\n/', trim($m[1]));
            $out = [];
            foreach ($lines as $line) {
                $line = trim($line);
                if (strpos($line, '=') !== false) {
                    list($k, $v) = array_pad(explode('=', $line, 2), 2, '');
                    $out[trim($k)] = trim($v);
                }
            }

            return $out;
        }

        return [];
    }

    private function renderJson(array $payload): void
    {
        header('Content-Type: application/json; charset=utf-8');

        $this->ajaxRender(json_encode($payload, JSON_UNESCAPED_UNICODE));
        exit();
    }
}