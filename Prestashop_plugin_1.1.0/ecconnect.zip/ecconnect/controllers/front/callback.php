<?php

use JetBrains\PhpStorm\NoReturn;

class EcconnectCallbackModuleFrontController extends ModuleFrontController
{
    public $ssl = true;

    public function postProcess()
    {
        if (empty($_POST)) {
            $this->addLog('empty POST', 2);
            $this->respondReverse('EMPTY_POST', $this->buildForwardUrlFallback());

            return;
        }

        $raw = @file_get_contents('php://input') ? : '';
        $this->addLog('[raw] ' . ($raw ? : '[empty]'), 1);

        $cartId = (int)Tools::getValue('OrderID');
        $tranCode = (string)Tools::getValue('TranCode', '');
        $sd = (string)Tools::getValue('SD', '');
        $merchantId = (string)Tools::getValue('MerchantID', '');
        $terminalId = (string)Tools::getValue('TerminalID', '');
        $purchaseTime = (string)Tools::getValue('PurchaseTime', '');
        $delay = Tools::getValue('Delay');
        $xid = (string)Tools::getValue('XID', '');
        $currency = (string)Tools::getValue('Currency', '');
        $altCurrency = (string)Tools::getValue('AltCurrency', '');
        $totalAmount = (string)Tools::getValue('TotalAmount', '');
        $altTotal = (string)Tools::getValue('AltTotalAmount', '');
        $approvalCode = (string)Tools::getValue('ApprovalCode', '');
        $signatureB64 = (string)Tools::getValue('Signature', '');
        $rrn = (string)Tools::getValue('Rrn', '');
        $upcToken = (string)Tools::getValue('UPCToken', '');
        $upcTokenExp = (string)Tools::getValue('UPCTokenExp', '');

        $this->addLog(sprintf('cartId=%d TranCode=%s Delay=%s', $cartId, $tranCode, (string)$delay), 1);

        // MerchantID;TerminalID;PurchaseTime;OrderID,Delay;XID;Currency,AltCurrency;TotalAmount,AltTotalAmount;SD;TranCode;ApprovalCode;UPCToken;{,UPCTokenExp;}
        $dataForSign = sprintf(
            '%s;%s;%s;%s,%s;%s;%s,%s;%s,%s;%s;%s;%s;%s%s',
            $merchantId,
            $terminalId,
            $purchaseTime,
            $cartId,
            (string)$delay,
            $xid,
            $currency,
            $altCurrency,
            $totalAmount,
            $altTotal,
            $sd,
            $tranCode,
            $approvalCode,
            $upcToken,
            $upcTokenExp !== '' ? ',' . $upcTokenExp . ';' : ''
        );

        $isTestMode = (bool)Configuration::get('ECCONNECT_TEST_MODE');
        $verified = false;
        if ($isTestMode) {
            $verified = true;
            $this->addLog('test mode: signature skipped', 1);
        } else {
            $cert = (string)Configuration::get('ECCONNECT_SERVER_CERT');
            $pubKey = $cert ? openssl_pkey_get_public($cert) : false;
            $sigBytes = base64_decode($signatureB64, true) ? : '';
            if ($pubKey && $sigBytes !== '') {
                $ok = openssl_verify($dataForSign, $sigBytes, $pubKey, OPENSSL_ALGO_SHA512);
                openssl_free_key($pubKey);
                $verified = ($ok === 1);
            }
            $this->addLog('signature verified=' . ($verified ? 'yes' : 'no'), $verified ? 1 : 2);
        }

        if (!$verified) {
            $this->respondReverse('INVALID_SIGNATURE', $this->buildForwardUrlByCart($cartId, $sd));

            return;
        }

        if ($tranCode !== '000') {
            $this->respondReverse('TranCode!=' . $tranCode, $this->buildForwardUrlByCart($cartId, $sd));

            return;
        }

        $idOrder = (int)Order::getIdByCartId($cartId);
        if ($idOrder <= 0) {
            $cart = new Cart($cartId);
            if (!Validate::isLoadedObject($cart)) {
                $this->addLog('cart not found id=' . $cartId, 3);
                $this->respondReverse('CART_NOT_FOUND', $this->buildForwardUrlFallback());

                return;
            }

            $customer = new Customer((int)$cart->id_customer);
            $currencyObj = new Currency((int)$cart->id_currency);

            $isPreAuthEnabled = (bool)Configuration::get('ECCONNECT_PREAUTH_MODE');
            $delayTruthy = !empty($delay);
            $onHoldStatusId = 17;
            $paidStatusId = (int)Configuration::get('PS_OS_PAYMENT');

            $initialStatus = ($isPreAuthEnabled && $delayTruthy) ? $onHoldStatusId : $paidStatusId;

            $amount = (float)$totalAmount / 100.0;

            $msg = 'UPC callback: TranCode=000' . (($isPreAuthEnabled && $delayTruthy) ? ' (preauth/on-hold)' : ' (captured)');

            $extra = [
                'transaction_id' => $xid,
                'approval_code' => $approvalCode,
                'rrn' => $rrn,
            ];

            $this->addLog('validateOrder start cart=' . (int)$cart->id . ' amount=' . $amount . ' status=' . $initialStatus, 1);

            $this->module->validateOrder(
                (int)$cart->id,
                $initialStatus,
                $amount,
                $this->module->displayName,
                $msg,
                $extra,
                (int)$currencyObj->id,
                false,
                $customer->secure_key
            );
            $idOrder = (int)$this->module->currentOrder;
            $this->addLog('validateOrder done idOrder=' . $idOrder, 1);
        }

        if ($idOrder > 0) {
            $order = new Order($idOrder);
            if (Validate::isLoadedObject($order)) {
                /*if ($sd !== '') {
                    $this->module->saveOrderMeta($order->id, ['_upc_session_token' => $sd]);
                }*/
                $this->module->saveOrderMeta($order->id, [
                    'purchase_time' => $purchaseTime,
                    'approval_code' => $approvalCode,
                    'rrn' => $rrn,
                    'signature' => $signatureB64,
                    'raw_payload' => $raw,
                ]);

                if ($upcToken !== '' && $upcTokenExp !== '') {
                    $this->setUPCToken(
                        (int)$order->id_customer,
                        (int)$this->context->shop->id,
                        $upcToken,
                        $upcTokenExp
                    );
                }

                $isPreAuthEnabled = (bool)Configuration::get('ECCONNECT_PREAUTH_MODE');
                $delayTruthy = !empty($delay);
                if (!($isPreAuthEnabled && $delayTruthy)) {
                    $successStatusId = (int)Configuration::get('ECCONNECT_SUCCESS_STATUS_ID');
                    if ($successStatusId <= 0) {
                        $successStatusId = (int)Configuration::get('PS_OS_PAYMENT');
                    }
                    if ((int)$order->current_state !== $successStatusId) {
                        $order->setCurrentState($successStatusId);
                    }
                }

                $forwardUrl = $this->buildForwardUrl($order->id, $sd);
                $this->respondApprove($forwardUrl);

                return;
            }
        }

        $this->respondReverse('ORDER_NOT_LOADED', $this->buildForwardUrlByCart($cartId, $sd));
    }

    /**
     * Збереження UPCToken/UPCTokenExp у вашій таблиці ps_ecconnect_customer_token
     * Якщо є запис — оновлюємо; якщо ні — додаємо.
     */
    protected function setUPCToken(int $idCustomer, int $idShop, string $token, string $exp): void
    {
        if ($idCustomer <= 0 || $idShop <= 0 || $token === '' || $exp === '') {
            return;
        }

        $q = new DbQuery();
        $q->select('t.`id_ecconnect_customer_token`')
          ->from('ecconnect_customer_token', 't')
          ->where('t.`id_customer`=' . (int)$idCustomer)
          ->where('t.`id_shop`=' . (int)$idShop)
          ->orderBy('t.`id_ecconnect_customer_token` DESC');

        PrestaShopLogger::addLog('[ecconnect] user ' . $q, 1);

        $row = Db::getInstance()->getRow($q);

        $data = [
            'id_customer' => (int)$idCustomer,
            'id_shop' => (int)$idShop,
            'token' => pSQL($token),
            'exp' => pSQL($exp),
            'date_upd' => date('Y-m-d H:i:s'),
        ];

        if ($row && !empty($row['id_ecconnect_customer_token'])) {
            Db::getInstance()->update('ecconnect_customer_token', $data, 'id_ecconnect_customer_token=' . (int)$row['id_ecconnect_customer_token']);
        } else {
            $data['date_add'] = date('Y-m-d H:i:s');
            Db::getInstance()->insert('ecconnect_customer_token', $data);
        }
    }

    /**
     * Будуємо forwardUrl.
     * Сигнатура: HMAC-SHA256("{$orderId}|{$sd}", private_key )
     */
    protected function buildForwardUrl(int $orderId, string $sd): string
    {
        $order = new Order($orderId);
        if (!Validate::isLoadedObject($order)) {
            return $this->buildForwardUrlFallback();
        }

        $secret = (string)Configuration::get('ECCONNECT_PRIVATE_KEY');
        $sig = hash_hmac('sha256', $order->id . '|' . $sd, $secret);

        return $this->context->link->getPageLink(
            'order-confirmation',
            true,
            null,
            [
                'id_order' => (int)$order->id,
                'id_cart' => (int)$order->id_cart,
                'key' => (string)$order->secure_key,
                'id_module' => (int)$this->module->id,
                'oid' => (int)$order->id,
                'sig' => $sig,
            ]
        );
    }

    /**
     * Коли order ще не створений, але маємо cartId → на крок підтвердження/стеження
     * (можна замінити на сторінку кошика або кастомну)
     */
    protected function buildForwardUrlByCart(int $cartId, string $sd): string
    {
        return $this->buildForwardUrlFallback();
    }

    /**
     * Абсолютний fallback (щоб forwardUrl був завжди)
     */
    protected function buildForwardUrlFallback(): string
    {
        return $this->context->link->getModuleLink('ecconnect', 'failed', []);
    }

    private function respondApprove(string $forwardUrl): void
    {
        header('Content-Type: text/plain');
        http_response_code(200);

        echo "MerchantID=" . Tools::getValue('MerchantID') . "\n";
        echo "TerminalID=" . Tools::getValue('TerminalID') . "\n";
        echo "OrderID=" . Tools::getValue('OrderID') . "\n";
        echo "Currency=" . Tools::getValue('Currency') . "\n";
        echo "TotalAmount=" . Tools::getValue('TotalAmount') . "\n";
        echo "XID=" . Tools::getValue('XID') . "\n";
        echo "TranCode=" . Tools::getValue('TranCode') . "\n";
        echo "PurchaseTime=" . Tools::getValue('PurchaseTime') . "\n\n";
        echo "Response.action=approve\n";
        echo "Response.reason=OK\n";
        echo "Response.forwardUrl={$forwardUrl}\n";
        exit;
    }

    private function respondReverse(string $reason, string $forwardUrl): void
    {
        header('Content-Type: text/plain');
        http_response_code(200);
        echo "Response.action=reverse\n";
        echo "Response.reason={$reason}\n";
        echo "Response.forwardUrl={$forwardUrl}\n";
        exit;
    }

    private function addLog(string $msg, int $level = 1): void
    {
        $isTestMode = (bool)Configuration::get('ECCONNECT_TEST_MODE');
        if ($isTestMode) {
            PrestaShopLogger::addLog('[ecconnect] ' . $msg, $level);
        }
    }
}