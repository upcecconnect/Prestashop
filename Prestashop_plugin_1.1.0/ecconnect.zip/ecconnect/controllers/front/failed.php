<?php

class EcconnectFailedModuleFrontController extends ModuleFrontController
{
    public $ssl = true;
    public $display_header = true;
    public $display_footer = true;
    public $display_column_left = false;
    public $display_column_right = false;


    public function initContent()
    {
        parent::initContent();

        $this->context->smarty->assign([
            'error_message' => $this->l('Оплата не пройшла або замовлення не було створено. Будь ласка, спробуйте ще раз.'),
            'retry_url' => $this->context->link->getPageLink('order', true, null, ['step' => 3]),
        ]);

        $this->setTemplate('module:ecconnect/views/templates/front/failed.tpl');
    }
}
