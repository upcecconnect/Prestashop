<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

class EcconnectOrderMeta extends ObjectModel
{
    public $id_ecconnect_order_meta;

    public $id_order;

    public $id_shop;

    public $purchase_time;

    public $approval_code;

    public $rrn;

    public $signature;

    public $raw_payload;

    public $date_add;

    public $date_upd;

    public static $definition = [
        'table' => 'ecconnect_order_meta',
        'primary' => 'id_ecconnect_order_meta',
        'fields' => [
            'id_order' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'id_shop' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'purchase_time' => ['type' => self::TYPE_STRING, 'validate' => 'isCleanHtml', 'required' => true, 'size' => 14],
            'approval_code' => ['type' => self::TYPE_STRING, 'validate' => 'isCleanHtml', 'required' => false, 'size' => 64],
            'rrn' => ['type' => self::TYPE_STRING, 'validate' => 'isCleanHtml', 'required' => false, 'size' => 64],
            'signature' => ['type' => self::TYPE_HTML, 'validate' => 'isString', 'required' => false],
            'raw_payload' => ['type' => self::TYPE_HTML, 'validate' => 'isString', 'required' => false],
            'date_add' => ['type' => self::TYPE_DATE, 'validate' => 'isDate'],
            'date_upd' => ['type' => self::TYPE_DATE, 'validate' => 'isDate'],
        ],
    ];

    /**
     * Зберігає/оновлює метадані замовлення за (id_order, id_shop).
     * $meta підтримує ключі: purchase_time, approval_code, rrn, signature, raw_payload
     */
    public static function saveMeta(int $idOrder, array $meta, int $idShop): bool
    {
        $allowed = ['purchase_time', 'approval_code', 'rrn', 'signature', 'raw_payload'];

        $data = [];
        foreach ($allowed as $k) {
            if (array_key_exists($k, $meta)) {
                $data[$k] = pSQL((string)$meta[$k], true);
            }
        }

        if (empty($data['purchase_time'])) {
            return false;
        }

        $db = Db::getInstance();

        $sql = 'SELECT `id_ecconnect_order_meta`
                  FROM `' . _DB_PREFIX_ . 'ecconnect_order_meta`
                 WHERE `id_order`=' . (int)$idOrder . ' AND `id_shop`=' . (int)$idShop . '
                 ORDER BY `id_ecconnect_order_meta` DESC';

        $existingId = (int)$db->getValue($sql);

        $now = date('Y-m-d H:i:s');
        $data['date_upd'] = pSQL($now);

        if ($existingId > 0) {

            return $db->update(
                'ecconnect_order_meta',
                $data,
                'id_ecconnect_order_meta=' . (int)$existingId
            );
        }

        $data['id_order'] = (int)$idOrder;
        $data['id_shop'] = (int)$idShop;
        $data['date_add'] = pSQL($now);

        return $db->insert('ecconnect_order_meta', $data);
    }

    /**
     * Повертає один запис мети (останній) у вигляді асоціативного масиву.
     */
    public static function getMeta(int $idOrder, int $idShop): array
    {
        $sql = 'SELECT `purchase_time`, `approval_code`, `rrn`, `signature`, `raw_payload`,
                       `date_add`, `date_upd`
                  FROM `' . _DB_PREFIX_ . 'ecconnect_order_meta`
                 WHERE `id_order`=' . (int)$idOrder . ' AND `id_shop`=' . (int)$idShop . '
                 ORDER BY `id_ecconnect_order_meta` DESC
                 LIMIT 1';

        $row = Db::getInstance()->getRow($sql);

        return $row ? : [];
    }

    public static function getByOrderId(int $idOrder, ?int $idShop = null): ?EcconnectOrderMeta
    {
        if ($idOrder <= 0) {
            return null;
        }

        if ($idShop === null) {
            $idShop = (int)Context::getContext()->shop->id;
        }

        $sql = new DbQuery();
        $sql->select('*')
            ->from('ecconnect_order_meta')
            ->where('id_order = ' . (int)$idOrder)
            ->where('id_shop = ' . (int)$idShop)
            ->orderBy('id_ecconnect_order_meta DESC');

        $row = Db::getInstance()->getRow($sql);

        if (!$row) {
            return null;
        }

        $meta = new EcconnectOrderMeta();
        $meta->hydrate($row);

        return $meta;
    }
}