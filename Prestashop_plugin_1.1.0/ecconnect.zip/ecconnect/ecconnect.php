<?php

if (!defined('_PS_VERSION_')) {
    exit;
}
require_once __DIR__ . '/classes/EcconnectOrderMeta.php';

use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

class Ecconnect extends PaymentModule
{
    /** @var array */
    private array $postErrors = [];

    /** Map: ISO => Numeric */
    public array $available_currencies = [
        'USD' => '840',
        'EUR' => '978',
        'UAH' => '980',
        'BAM' => '977',
        'HUF' => '348',
        'BGN' => '975',
        'RSD' => '941',
        'ALL' => '008',
    ];

    public function __construct()
    {
        $this->name = 'ecconnect';
        $this->tab = 'payments_gateways';
        $this->version = '1.1.0';
        $this->author = 'upc.ua';
        $this->currencies = true;
        $this->currencies_mode = 'checkbox';
        $this->bootstrap = true;
        $this->controllers = ['redirect', 'callback', 'result'];

        parent::__construct();

        $this->displayName = $this->l('ECommerceConnect');
        $this->description = $this->l('Accept online payments');

        $this->ps_versions_compliancy = ['min' => '1.7', 'max' => _PS_VERSION_];

        if (!count(\Currency::checkPaymentCurrencies($this->id))) {
            $this->warning = $this->l('No currency has been set for this module');
        }
    }

    /* ==========================
     *  Install / Uninstall
     * ========================== */
    public function install()
    {
        \Configuration::updateValue('ECCONNECT_ENABLED', 1);
        \Configuration::updateValue('ECCONNECT_ACTIVE_MODE', 1); // alias of ENABLED, kept for BC
        \Configuration::updateValue('ECCONNECT_TITLE', 'eCommerceConnect');
        \Configuration::updateValue('ECCONNECT_DESCRIPTION', 'Pay with eCommerceConnect (Debit/Credit Cards)');
        \Configuration::updateValue('ECCONNECT_TEST_MODE', 1);
        \Configuration::updateValue('ECCONNECT_GATEWAY_DOMAIN', 'https://secure.upc.ua/go/pay');
        \Configuration::updateValue('ECCONNECT_GATEWAY_DOMAIN_TEST', 'https://ecg.test.upc.ua/go/pay');
        \Configuration::updateValue('ECCONNECT_MERCHANT_ID', '');
        \Configuration::updateValue('ECCONNECT_TERMINAL_ID', '');
        \Configuration::updateValue('ECCONNECT_PRIVATE_KEY', '');
        \Configuration::updateValue('ECCONNECT_SERVER_CERT', '');
        \Configuration::updateValue('ECCONNECT_PRIVATE_KEY_TEST', '');
        \Configuration::updateValue('ECCONNECT_SERVER_CERT_TEST', '');
        \Configuration::updateValue('ECCONNECT_CURRENCY', '980'); // UAH default
        \Configuration::updateValue('ECCONNECT_ALT_CURRENCY', '840'); // USD
        \Configuration::updateValue('ECCONNECT_LANG', 'en');
        \Configuration::updateValue('ECCONNECT_PREAUTH_MODE', 0);

        $ow_status = \Configuration::get('ECCONNECT_STATE_WAITING');
        $orderState = $ow_status === false ? new \OrderState() : new \OrderState((int)$ow_status);
        foreach (\Language::getLanguages() as $language) {
            $code = \Tools::strtolower($language['iso_code']);
            $name = $code === 'uk' ? 'Очікування завершення оплати' : ($code === 'ru' ? 'Ожидание завершения оплаты' : 'Awaiting for payment');
            $orderState->name[$language['id_lang']] = $name;
        }
        $orderState->send_email = false;
        $orderState->color = '#4169E1';
        $orderState->hidden = false;
        $orderState->module_name = $this->name;
        $orderState->delivery = false;
        $orderState->logable = false;
        $orderState->invoice = false;
        $orderState->unremovable = true;
        $orderState->save();
        \Configuration::updateValue('ECCONNECT_STATE_WAITING', (int)$orderState->id);

        return parent::install()
               && $this->installDb()
               && $this->registerHook('displayHeader')
               && $this->registerHook('displayBackOfficeHeader')
               && $this->registerHook('paymentOptions')
               && $this->registerHook('actionOrderStatusPostUpdate')
               && $this->registerHook('displayOrderConfirmation')
               && $this->registerHook('displayPayment')
               && $this->registerHook('paymentReturn')
               && $this->registerHook('displayAdminOrderMain')
               && $this->registerHook('actionAdminControllerSetMedia')
               && $this->installAdminTab();
    }

    protected function installAdminTab(): bool
    {
        $tab = new Tab();
        $tab->active = 1;
        $tab->class_name = 'AdminEcconnectCapture';
        $tab->id_parent = (int)Tab::getIdFromClassName('AdminParentOrders');
        foreach (Language::getLanguages(false) as $lang) {
            $tab->name[$lang['id_lang']] = 'EcommerceConnect Capture';
        }
        $tab->module = $this->name;

        return (bool)$tab->add();
    }

    public function uninstall()
    {
        $keys = [
            'ECCONNECT_ENABLED',
            'ECCONNECT_ACTIVE_MODE',
            'ECCONNECT_TITLE',
            'ECCONNECT_DESCRIPTION',
            'ECCONNECT_TEST_MODE',
            'ECCONNECT_GATEWAY_DOMAIN',
            'ECCONNECT_GATEWAY_DOMAIN_TEST',
            'ECCONNECT_MERCHANT_ID',
            'ECCONNECT_TERMINAL_ID',
            'ECCONNECT_PRIVATE_KEY',
            'ECCONNECT_SERVER_CERT',
            'ECCONNECT_PRIVATE_KEY_TEST',
            'ECCONNECT_SERVER_CERT_TEST',
            'ECCONNECT_CURRENCY',
            'ECCONNECT_ALT_CURRENCY',
            'ECCONNECT_LANG',
            'ECCONNECT_PREAUTH_MODE',
            'ECCONNECT_STATE_WAITING',
            'ECCONNECT_SUCCESS_STATUS_ID',
        ];
        foreach ($keys as $k) {
            \Configuration::deleteByName($k);
        }

        $id = (int)Tab::getIdFromClassName('AdminEcconnectCapture');
        if ($id) {
            $tab = new Tab($id);
            $tab->delete();
        }

        return $this->unregisterHook('displayHeader')
               && $this->unregisterHook('displayBackOfficeHeader')
               && $this->unregisterHook('paymentOptions')
               && $this->unregisterHook('actionOrderStatusPostUpdate')
               && $this->unregisterHook('displayOrderConfirmation')
               && $this->unregisterHook('displayPayment')
               && $this->unregisterHook('paymentReturn')
               && $this->uninstallDb()
               && parent::uninstall();
    }

    /* ==========================
     *  Configuration UI
     * ========================== */
    public function getContent()
    {
        $output = '';
        if ((bool)\Tools::isSubmit('submitEcconnectModule') === true) {
            $this->postValidation();
            if (empty($this->postErrors)) {
                $this->postProcess();
                $output .= $this->displayConfirmation($this->l('Settings updated'));
            }
        }
        foreach ($this->postErrors as $error) {
            $output .= $this->displayError($error);
        }

        return $output . $this->renderForm();
    }

    private function postValidation(): void
    {
        // Required basics
        $url_live = trim((string)\Tools::getValue('ECCONNECT_GATEWAY_DOMAIN'));
        $url_test = trim((string)\Tools::getValue('ECCONNECT_GATEWAY_DOMAIN_TEST'));
        $merchant = trim((string)\Tools::getValue('ECCONNECT_MERCHANT_ID'));
        $terminal = trim((string)\Tools::getValue('ECCONNECT_TERMINAL_ID'));
        $title = trim((string)\Tools::getValue('ECCONNECT_TITLE'));
        $desc = (string)\Tools::getValue('ECCONNECT_DESCRIPTION');

        if ($title === '') {
            $this->postErrors[] = $this->l('Title is required');
        }
        if ($desc === '') {
            $this->postErrors[] = $this->l('Description is required');
        }

        if ($url_live === '' || !filter_var($url_live, FILTER_VALIDATE_URL)) {
            $this->postErrors[] = $this->l('Payment URL (live) is required and must be a valid URL');
        }
        if ($url_test === '' || !filter_var($url_test, FILTER_VALIDATE_URL)) {
            $this->postErrors[] = $this->l('Payment URL (test) is required and must be a valid URL');
        }
        if ($merchant === '' || !preg_match('/^[A-Za-z0-9_-]+$/', $merchant)) {
            $this->postErrors[] = $this->l('Merchant ID is required and must be alphanumeric');
        }
        if ($terminal === '' || !preg_match('/^[A-Za-z0-9_-]+$/', $terminal)) {
            $this->postErrors[] = $this->l('Terminal ID is required and must be alphanumeric');
        }

        $currency = (string)\Tools::getValue('ECCONNECT_CURRENCY');
        $allowedNums = array_values($this->available_currencies);
        if ($currency === '' || !in_array($currency, $allowedNums, true)) {
            $this->postErrors[] = $this->l('Transaction currency is invalid');
        }
        $alt = (string)\Tools::getValue('ECCONNECT_ALT_CURRENCY');
        if (!in_array($alt, ['840', '978'], true)) { // USD/EUR only
            $this->postErrors[] = $this->l('Alternative currency must be USD (840) or EUR (978)');
        }

        $lang = (string)\Tools::getValue('ECCONNECT_LANG');
        $allowedLangs = ['en', 'uk', 'sr', 'hu', 'bg', 'sq', 'bs', 'de'];
        if ($lang === '' || !in_array($lang, $allowedLangs, true)) {
            $this->postErrors[] = $this->l('Language value is invalid');
        }

        $isTest = (bool)\Tools::getValue('ECCONNECT_TEST_MODE');
        $liveKeyExists = (string)\Configuration::get('ECCONNECT_PRIVATE_KEY') !== '';
        $liveCrtExists = (string)\Configuration::get('ECCONNECT_SERVER_CERT') !== '';
        $testKeyExists = (string)\Configuration::get('ECCONNECT_PRIVATE_KEY_TEST') !== '';
        $testCrtExists = (string)\Configuration::get('ECCONNECT_SERVER_CERT_TEST') !== '';

        if (!empty($_FILES['ECCONNECT_UPLOAD_KEY']['tmp_name'])) {
            $liveKeyExists = true;
        }
        if (!empty($_FILES['ECCONNECT_UPLOAD_CERT']['tmp_name'])) {
            $liveCrtExists = true;
        }
        if (!empty($_FILES['ECCONNECT_UPLOAD_KEY_TEST']['tmp_name'])) {
            $testKeyExists = true;
        }
        if (!empty($_FILES['ECCONNECT_UPLOAD_CERT_TEST']['tmp_name'])) {
            $testCrtExists = true;
        }

        if ($isTest && (!$testKeyExists || !$testCrtExists)) {
            $this->postErrors[] = $this->l('Test private key and test certificate are required in test mode');
        }
        if (!$isTest && (!$liveKeyExists || !$liveCrtExists)) {
            $this->postErrors[] = $this->l('Live private key and live certificate are required in live mode');
        }

        $checkPem = function ($content, $label) {
            if ($content === null || $content === '') {
                return;
            }
            if (strpos($content, '-----BEGIN') === false) {
                $this->postErrors[] = sprintf($this->l('%s does not look like a valid PEM content'), $label);
            }
        };
        $checkPem($this->readUpload('ECCONNECT_UPLOAD_KEY'), 'Private key');
        $checkPem($this->readUpload('ECCONNECT_UPLOAD_CERT'), 'Server certificate');
        $checkPem($this->readUpload('ECCONNECT_UPLOAD_KEY_TEST'), 'Test private key');
        $checkPem($this->readUpload('ECCONNECT_UPLOAD_CERT_TEST'), 'Test certificate');
    }

    protected function postProcess(): void
    {
        $fields = [
            'ECCONNECT_ENABLED',
            'ECCONNECT_ACTIVE_MODE',
            'ECCONNECT_TITLE',
            'ECCONNECT_DESCRIPTION',
            'ECCONNECT_TEST_MODE',
            'ECCONNECT_GATEWAY_DOMAIN',
            'ECCONNECT_GATEWAY_DOMAIN_TEST',
            'ECCONNECT_MERCHANT_ID',
            'ECCONNECT_TERMINAL_ID',
            'ECCONNECT_CURRENCY',
            'ECCONNECT_ALT_CURRENCY',
            'ECCONNECT_LANG',
            'ECCONNECT_PREAUTH_MODE',
            'ECCONNECT_SUCCESS_STATUS_ID',
        ];
        foreach ($fields as $key) {
            \Configuration::updateValue($key, \Tools::getValue($key));
        }

        $this->maybeSavePemUpload('ECCONNECT_UPLOAD_KEY', 'ECCONNECT_PRIVATE_KEY');
        $this->maybeSavePemUpload('ECCONNECT_UPLOAD_CERT', 'ECCONNECT_SERVER_CERT');
        $this->maybeSavePemUpload('ECCONNECT_UPLOAD_KEY_TEST', 'ECCONNECT_PRIVATE_KEY_TEST');
        $this->maybeSavePemUpload('ECCONNECT_UPLOAD_CERT_TEST', 'ECCONNECT_SERVER_CERT_TEST');
    }

    private function readUpload(string $field): ?string
    {
        return !empty($_FILES[$field]['tmp_name']) ? \Tools::file_get_contents($_FILES[$field]['tmp_name']) : null;
    }

    private function maybeSavePemUpload(string $uploadField, string $configKey): void
    {
        $content = $this->readUpload($uploadField);
        if ($content !== null && $content !== '' && $content !== (string)\Configuration::get($configKey)) {
            \Configuration::updateValue($configKey, $content);
        }
    }

    protected function renderForm(): string
    {
        $helper = new \HelperForm();
        $helper->show_toolbar = false;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = \Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitEcconnectModule';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
                                . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
        $helper->token = \Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = [
            'fields_value' => $this->getConfigFormValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        ];

        return $helper->generateForm([$this->getConfigForm()]);
    }

    protected function getConfigForm(): array
    {
        $options = [];
        foreach (\OrderState::getOrderStates($this->context->language->id) as $state) {
            if (empty($state['module_name'])) {
                $options[] = ['status_id' => $state['id_order_state'], 'name' => $state['name'] . ' [ID: ' . $state['id_order_state'] . ']'];
            }
        }

        $currencyOptions = [];
        foreach ($this->available_currencies as $iso => $num) {
            $currencyOptions[] = ['id' => $num, 'name' => $iso . ' – ' . $num];
        }
        $altCurrencyOptions = [];
        foreach (['840' => 'USD', '978' => 'EUR'] as $num => $iso) {
            $altCurrencyOptions[] = ['id' => $num, 'name' => $iso . ' – ' . $num];
        }

        $langOptions = [
            ['id' => 'en', 'name' => $this->l('English (default)')],
            ['id' => 'uk', 'name' => $this->l('Ukrainian (UAH)')],
            ['id' => 'sr', 'name' => $this->l('Serbian (RSD)')],
            ['id' => 'hu', 'name' => $this->l('Hungarian (HUF)')],
            ['id' => 'bg', 'name' => $this->l('Bulgarian (BGN)')],
            ['id' => 'sq', 'name' => $this->l('Albanian (ALL)')],
            ['id' => 'bs', 'name' => $this->l('Bosnian (BAM)')],
            ['id' => 'de', 'name' => $this->l('German (EUR)')],
        ];

        return [
            'form' => [
                'legend' => [
                    'title' => $this->l('Settings'),
                    'icon' => 'icon-cogs',
                ],
                'input' => [
                    [
                        'type' => 'switch',
                        'label' => $this->l('Enable/Disable'),
                        'name' => 'ECCONNECT_ENABLED',
                        'is_bool' => true,
                        'values' => [
                            ['id' => 'enabled_on', 'value' => 1, 'label' => $this->l('Enabled')],
                            ['id' => 'enabled_off', 'value' => 0, 'label' => $this->l('Disabled')],
                        ],
                        'desc' => $this->l('Master switch for gateway availability.'),
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Title'),
                        'name' => 'ECCONNECT_TITLE',
                        'desc' => $this->l('Shown to customer during checkout.'),
                        'required' => true,
                    ],
                    [
                        'type' => 'textarea',
                        'label' => $this->l('Description'),
                        'name' => 'ECCONNECT_DESCRIPTION',
                        'desc' => $this->l('Checkout description below the payment option.'),
                        'autoload_rte' => false,
                        'required' => true,
                    ],
                    [
                        'type' => 'switch',
                        'label' => $this->l('Sandbox (Test mode)'),
                        'name' => 'ECCONNECT_TEST_MODE',
                        'is_bool' => true,
                        'values' => [
                            ['id' => 'test_on', 'value' => 1, 'label' => $this->l('Enabled')],
                            ['id' => 'test_off', 'value' => 0, 'label' => $this->l('Disabled')],
                        ],
                        'desc' => $this->l('Place the gateway in test mode.'),
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Payment URL (Live)'),
                        'name' => 'ECCONNECT_GATEWAY_DOMAIN',
                        'desc' => $this->l('e.g. https://secure.upc.ua/go/pay'),
                        'required' => true,
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Payment URL (Test)'),
                        'name' => 'ECCONNECT_GATEWAY_DOMAIN_TEST',
                        'desc' => $this->l('e.g. https://ecg.test.upc.ua/go/pay'),
                        'required' => true,
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Merchant ID'),
                        'name' => 'ECCONNECT_MERCHANT_ID',
                        'required' => true,
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Terminal ID'),
                        'name' => 'ECCONNECT_TERMINAL_ID',
                        'required' => true,
                    ],
                    [
                        'type' => 'select',
                        'label' => $this->l('Transaction Currency'),
                        'name' => 'ECCONNECT_CURRENCY',
                        'options' => ['query' => $currencyOptions, 'id' => 'id', 'name' => 'name'],
                        'desc' => $this->l('Numeric ISO 4217 code to send to gateway.'),
                    ],
                    [
                        'type' => 'select',
                        'label' => $this->l('AltCurrency (display only)'),
                        'name' => 'ECCONNECT_ALT_CURRENCY',
                        'options' => ['query' => $altCurrencyOptions, 'id' => 'id', 'name' => 'name'],
                        'desc' => $this->l('Optional visual alternative currency (USD/EUR).'),
                    ],
                    [
                        'type' => 'select',
                        'label' => $this->l('Gateway interface language'),
                        'name' => 'ECCONNECT_LANG',
                        'options' => ['query' => $langOptions, 'id' => 'id', 'name' => 'name'],
                    ],
                    [
                        'type' => 'switch',
                        'label' => $this->l('Pre-authorization'),
                        'name' => 'ECCONNECT_PREAUTH_MODE',
                        'is_bool' => true,
                        'values' => [
                            ['id' => 'preauth_on', 'value' => 1, 'label' => $this->l('Enabled')],
                            ['id' => 'preauth_off', 'value' => 0, 'label' => $this->l('Disabled')],
                        ],
                        'desc' => $this->l('Capture later instead of immediate charge (if supported).'),
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Private key (Live)'),
                        'name' => 'ECCONNECT_PRIVATE_KEY',
                        'readonly' => true,
                        'desc' => $this->l('Shown as “Saved” if present. Upload new file to replace.'),
                    ],
                    [
                        'type' => 'file',
                        'label' => $this->l('Upload Private key (.pem) – Live'),
                        'name' => 'ECCONNECT_UPLOAD_KEY',
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Server certificate (Live)'),
                        'name' => 'ECCONNECT_SERVER_CERT',
                        'readonly' => true,
                        'desc' => $this->l('Shown as “Saved” if present. Upload new file to replace.'),
                    ],
                    [
                        'type' => 'file',
                        'label' => $this->l('Upload Server certificate (.cert) – Live'),
                        'name' => 'ECCONNECT_UPLOAD_CERT',
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Private key (Test)'),
                        'name' => 'ECCONNECT_PRIVATE_KEY_TEST',
                        'readonly' => true,
                        'desc' => $this->l('Shown as “Saved” if present. Upload new file to replace.'),
                    ],
                    [
                        'type' => 'file',
                        'label' => $this->l('Upload Private key (.pem) – Test'),
                        'name' => 'ECCONNECT_UPLOAD_KEY_TEST',
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Server certificate (Test)'),
                        'name' => 'ECCONNECT_SERVER_CERT_TEST',
                        'readonly' => true,
                        'desc' => $this->l('Shown as “Saved” if present. Upload new file to replace.'),
                    ],
                    [
                        'type' => 'file',
                        'label' => $this->l('Upload Server certificate (.cert) – Test'),
                        'name' => 'ECCONNECT_UPLOAD_CERT_TEST',
                    ],

                    [
                        'type' => 'select',
                        'prefix' => '<i class="icon icon-key"></i>',
                        'name' => 'ECCONNECT_SUCCESS_STATUS_ID',
                        'label' => $this->l('Status after success payment'),
                        'options' => [
                            'query' => $options,
                            'id' => 'status_id',
                            'name' => 'name',
                        ],
                    ],
                ],
                'submit' => ['title' => $this->l('Save')],
            ],
        ];
    }

    protected function getConfigFormValues(): array
    {
        $mask = function (string $key) {
            return \Configuration::get($key) ? '✓ ' . $this->l('Saved') : '';
        };

        return [
            'ECCONNECT_ENABLED' => (int)\Configuration::get('ECCONNECT_ENABLED', 1),
            'ECCONNECT_TITLE' => (string)\Configuration::get('ECCONNECT_TITLE', 'eCommerceConnect'),
            'ECCONNECT_DESCRIPTION' => (string)\Configuration::get('ECCONNECT_DESCRIPTION', 'Pay with eCommerceConnect (Debit/Credit Cards)'),
            'ECCONNECT_TEST_MODE' => (int)\Configuration::get('ECCONNECT_TEST_MODE', 1),
            'ECCONNECT_GATEWAY_DOMAIN' => (string)\Configuration::get('ECCONNECT_GATEWAY_DOMAIN', 'https://secure.upc.ua/go/pay'),
            'ECCONNECT_GATEWAY_DOMAIN_TEST' => (string)\Configuration::get('ECCONNECT_GATEWAY_DOMAIN_TEST', 'https://ecg.test.upc.ua/go/pay'),
            'ECCONNECT_MERCHANT_ID' => (string)\Configuration::get('ECCONNECT_MERCHANT_ID', ''),
            'ECCONNECT_TERMINAL_ID' => (string)\Configuration::get('ECCONNECT_TERMINAL_ID', ''),
            'ECCONNECT_CURRENCY' => (string)\Configuration::get('ECCONNECT_CURRENCY', '980'),
            'ECCONNECT_ALT_CURRENCY' => (string)\Configuration::get('ECCONNECT_ALT_CURRENCY', '840'),
            'ECCONNECT_LANG' => (string)\Configuration::get('ECCONNECT_LANG', 'en'),
            'ECCONNECT_PREAUTH_MODE' => (int)\Configuration::get('ECCONNECT_PREAUTH_MODE', 0),
            'ECCONNECT_PRIVATE_KEY' => $mask('ECCONNECT_PRIVATE_KEY'),
            'ECCONNECT_SERVER_CERT' => $mask('ECCONNECT_SERVER_CERT'),
            'ECCONNECT_PRIVATE_KEY_TEST' => $mask('ECCONNECT_PRIVATE_KEY_TEST'),
            'ECCONNECT_SERVER_CERT_TEST' => $mask('ECCONNECT_SERVER_CERT_TEST'),
            'ECCONNECT_SUCCESS_STATUS_ID' => (string)\Configuration::get('ECCONNECT_SUCCESS_STATUS_ID'),
        ];
    }

    /* ==========================
     *  Hooks / Front
     * ========================== */
    public function hookBackOfficeHeader()
    {
        if (\Tools::getValue('module_name') === $this->name) {
            $this->context->controller->addJS($this->_path . 'views/js/back.js');
            $this->context->controller->addCSS($this->_path . 'views/css/back.css');
        }
    }

    public function hookDisplayHeader()
    {
        $this->context->controller->addJS($this->_path . 'views/js/front.js');
        $this->context->controller->addCSS($this->_path . 'views/css/front.css');
    }

    public function hookPaymentOptions($params)
    {
        if (!$this->active || !\Configuration::get('ECCONNECT_ENABLED')) {
            return;
        }
        if (!$this->checkCurrency($params['cart'])) {
            return;
        }

        $cart = $params['cart'];
        $context = $this->context;

        $isTest = (bool)\Configuration::get('ECCONNECT_TEST_MODE');
        $gateway = (string)\Configuration::get($isTest ? 'ECCONNECT_GATEWAY_DOMAIN_TEST' : 'ECCONNECT_GATEWAY_DOMAIN');
        $merchantId = (string)\Configuration::get('ECCONNECT_MERCHANT_ID');
        $terminalId = (string)\Configuration::get('ECCONNECT_TERMINAL_ID');
        $privRaw = (string)\Configuration::get($isTest ? 'ECCONNECT_PRIVATE_KEY_TEST' : 'ECCONNECT_PRIVATE_KEY');

        $lang = (string)\Configuration::get('ECCONNECT_LANG', $context->language->iso_code);
        $preauth = (int)\Configuration::get('ECCONNECT_PREAUTH_MODE', 0);

        $title = (string)\Configuration::get('ECCONNECT_TITLE', $this->displayName);
        $description = (string)\Configuration::get('ECCONNECT_DESCRIPTION', '');

        $orderTotal = (float)$cart->getOrderTotal();

        $orderCurrencyObj = new \Currency($cart->id_currency);
        $orderCurrencyNum = $orderCurrencyObj->iso_code_num;
        $orderCurrencyCode = $orderCurrencyObj->iso_code;

        $contractCurrencyNum = \Configuration::get('ECCONNECT_CURRENCY');
        $contractCurrencyNum = $contractCurrencyNum ? : $orderCurrencyNum;

        $altCurrencyNum = \Configuration::get('ECCONNECT_ALT_CURRENCY');
        if ($orderCurrencyNum === $contractCurrencyNum || !in_array($altCurrencyNum, ['840', '978'], true)) {
            $altCurrencyNum = $contractCurrencyNum;
        }

        $numericToAlpha = array_flip($this->available_currencies);
        $contractCurrencyAlpha = $numericToAlpha[$contractCurrencyNum] ?? $orderCurrencyCode;
        $altCurrencyAlpha = $numericToAlpha[$altCurrencyNum] ?? $contractCurrencyAlpha;

        $contractCurrencyId = (int)\Currency::getIdByIsoCode($contractCurrencyAlpha);
        $altCurrencyId = (int)\Currency::getIdByIsoCode($altCurrencyAlpha);

        $contractCurrencyObj = $contractCurrencyId ? new \Currency($contractCurrencyId) : $orderCurrencyObj;
        $altCurrencyObj = $altCurrencyId ? new \Currency($altCurrencyId) : $contractCurrencyObj;

        $primaryInContract = $orderCurrencyNum === $contractCurrencyNum
            ? (float)$orderTotal
            : (float)\Tools::convertPriceFull($orderTotal, $orderCurrencyObj, $contractCurrencyObj);

        $altInAlt = ($altCurrencyNum === $contractCurrencyNum)
            ? $primaryInContract
            : (float)\Tools::convertPriceFull($primaryInContract, $contractCurrencyObj, $altCurrencyObj);

        $totalAmountCents = (int)round($primaryInContract * 100);
        $altTotalAmountCents = (int)round($altInAlt * 100);

        //   $contractCurrencyNum  -> в поле `Currency`
        //   $altCurrencyNum       -> в поле `AltCurrency`
        //   $totalAmountCents     -> в поле `TotalAmount`
        //   $altTotalAmountCents  -> в поле `AltTotalAmount`

        $purchaseTime = date('ymdHis');
        $orderId = (int)$cart->id;
        $delay = $preauth ? '1' : '0';

        $sdRaw = $context->cookie->id_guest . '|' . $orderId . '|' . $purchaseTime;
        $sd = sha1($sdRaw);

        $upcToken = $this->getCustomerUpcToken((int)$context->customer->id);

        $b64sign = '';
        if (!empty($privRaw)) {
            $privKey = $privRaw;

            // Рядок даних: "$merchantID;$terminalID;$purchaseTime;$orderID,$delay;$contract_currency,$alt_currency;$total_amount,$alt_total;$sd;"
            $signString = $merchantId . ';' . $terminalId . ';' . $purchaseTime . ';' .
                          $orderId . ',' . $delay . ';' .
                          $contractCurrencyNum . ',' . $altCurrencyNum . ';' .
                          $totalAmountCents . ',' . $altTotalAmountCents . ';' .
                          $sd . ';';

            $pkeyid = openssl_pkey_get_private($privKey);
            if ($pkeyid) {
                if (openssl_sign($signString, $signature, $pkeyid, OPENSSL_ALGO_SHA512)) {
                    $b64sign = base64_encode($signature);
                }
                if (PHP_VERSION_ID < 80000) {
                    openssl_free_key($pkeyid);
                } else {
                    openssl_pkey_free($pkeyid);
                }
            }
        }

        $actionUrl = rtrim($gateway, '/') . '/go/pay';
        //$actionUrl = rtrim($gateway, '/') . '/rbrs/pay';

        $inputs = [
            'Version' => ['name' => 'Version', 'type' => 'hidden', 'value' => '1'],
            'MerchantID' => ['name' => 'MerchantID', 'type' => 'hidden', 'value' => $merchantId],
            'TerminalID' => ['name' => 'TerminalID', 'type' => 'hidden', 'value' => $terminalId],
            'OrderID' => ['name' => 'OrderID', 'type' => 'hidden', 'value' => (string)$orderId],
            'Delay' => ['name' => 'Delay', 'type' => 'hidden', 'value' => $delay],
            'TotalAmount' => ['name' => 'TotalAmount', 'type' => 'hidden', 'value' => (string)$totalAmountCents],
            'AltTotalAmount' => ['name' => 'AltTotalAmount', 'type' => 'hidden', 'value' => (string)$altTotalAmountCents],
            'Currency' => ['name' => 'Currency', 'type' => 'hidden', 'value' => (string)$contractCurrencyNum],
            'AltCurrency' => ['name' => 'AltCurrency', 'type' => 'hidden', 'value' => (string)$altCurrencyNum],
            'PurchaseTime' => ['name' => 'PurchaseTime', 'type' => 'hidden', 'value' => $purchaseTime],
            'PurchaseDesc' => ['name' => 'PurchaseDesc', 'type' => 'hidden', 'value' => \Configuration::get('PS_SHOP_NAME') . ' - ' . $orderId],
            'SD' => ['name' => 'SD', 'type' => 'hidden', 'value' => $sd],
            'locale' => ['name' => 'locale', 'type' => 'hidden', 'value' => $lang],
            'Signature' => ['name' => 'Signature', 'type' => 'hidden', 'value' => $b64sign],
        ];

        if ($upcToken !== '') {
            $inputs['UPCToken'] = ['name' => 'UPCToken', 'type' => 'hidden', 'value' => $upcToken];
        }

        $option = new PaymentOption();
        $option->setCallToActionText($title)
               ->setModuleName($this->name)
               ->setLogo(\Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/logo.png'))
               ->setAction($actionUrl)
               ->setInputs($inputs);

        if (!empty($description)) {
            $option->setAdditionalInformation('<p>' . \Tools::safeOutput($description) . '</p>');
        }

        return [$option];
    }

    public function checkCurrency($cart): bool
    {
        $currency_order = new \Currency($cart->id_currency);
        $currencies_module = $this->getCurrency($cart->id_currency);
        if (is_array($currencies_module)) {
            foreach ($currencies_module as $currency_module) {
                if ((int)$currency_order->id === (int)$currency_module['id_currency']) {
                    return true;
                }
            }
        }

        return false;
    }

    private function createConfirmationUrl(\Cart $cart): string
    {
        $customer = new \Customer($cart->id_customer);

        return $this->context->shop->getBaseURL()
               . 'index.php?controller=order-confirmation&id_cart=' . (int)$cart->id
               . '&id_module=' . (int)$this->id
               . '&key=' . $customer->secure_key;
    }

    public function hookPaymentReturn($params)
    {
        if (!$this->active) {
            return;
        }

        return $this->display(__FILE__, 'confirmation.tpl');
    }

    public function hookActionOrderStatusPostUpdate($params)
    { /* extend if needed */
    }

    public function hookDisplayPayment($params)
    { /* paymentOptions is primary in PS >=1.7 */
    }

    private function saveCustomerUpcToken(int $idCustomer, string $token, string $expMMYYYY): bool
    {
        if ($idCustomer <= 0 || $token === '' || !preg_match('/^\d{6}$/', $expMMYYYY)) {
            return false;
        }
        $tokenEnc = $token;

        $now = date('Y-m-d H:i:s');
        $data = [
            'id_customer' => (int)$idCustomer,
            'token' => pSQL($tokenEnc, true),
            'exp' => pSQL($expMMYYYY),
            'date_add' => $now,
            'date_upd' => $now,
        ];

        $sql = 'INSERT INTO `' . _DB_PREFIX_ . 'ecconnect_customer_token`
            (`id_customer`,`token`,`exp`,`date_add`,`date_upd`)
            VALUES (' . (int)$data['id_customer'] . ', "' . $data['token'] . '", "' . $data['exp'] . '", "' . $data['date_add'] . '", "' . $data['date_upd'] . '")
            ON DUPLICATE KEY UPDATE
              `token` = VALUES(`token`),
              `exp` = VALUES(`exp`),
              `date_upd` = VALUES(`date_upd`)';

        return (bool)Db::getInstance()->execute($sql);
    }

    private function getCustomerUpcToken(int $idCustomer): string
    {
        if ($idCustomer <= 0) {
            return '';
        }

        $idShop = (int)$this->context->shop->id;

        $q = new DbQuery();
        $q->select('t.`token`, t.`exp`')
          ->from('ecconnect_customer_token', 't')
          ->where('t.`id_customer`=' . (int)$idCustomer)
          ->where('t.`id_shop`=' . (int)$idShop)
          ->where(
              't.`id_ecconnect_customer_token` = (SELECT MAX(tt.`id_ecconnect_customer_token`)
             FROM `' . _DB_PREFIX_ . 'ecconnect_customer_token` tt
             WHERE tt.`id_customer`=' . (int)$idCustomer . '
               AND tt.`id_shop`=' . (int)$idShop . ')'
          );

        $row = Db::getInstance()->getRow($q);
        if (!$row || empty($row['token']) || empty($row['exp'])) {
            return '';
        }

        $exp = (string)$row['exp'];
        $expMonth = (int)substr($exp, 0, 2);
        $expYear = (int)substr($exp, 2, 4);
        $curMonth = (int)date('m');
        $curYear = (int)date('Y');

        $isValid = ($expYear > $curYear) || ($expYear === $curYear && $expMonth >= $curMonth);

        return $isValid ? (string)$row['token'] : '';
    }

    private function installDb(): bool
    {
        $ok = true;

        $sql1 = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'ecconnect_customer_token` (
            `id_ecconnect_customer_token` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `id_customer` INT UNSIGNED NOT NULL,
            `id_shop` INT UNSIGNED NOT NULL,
            `token` TEXT NOT NULL,
            `exp` CHAR(6) NOT NULL,            -- формат MMYYYY
            `date_add` DATETIME NOT NULL,
            `date_upd` DATETIME NOT NULL,
            PRIMARY KEY (`id_ecconnect_customer_token`),
            UNIQUE KEY `uniq_customer_shop` (`id_customer`, `id_shop`),
            KEY `idx_shop` (`id_shop`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;';
        $ok = $ok && Db::getInstance()->execute($sql1);

        $sql2 = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'ecconnect_order_meta` (
            `id_ecconnect_order_meta` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `id_order` INT UNSIGNED NOT NULL,
            `id_shop` INT UNSIGNED NOT NULL,
            `purchase_time` CHAR(14) NOT NULL,
            `approval_code` VARCHAR(64) DEFAULT NULL,
            `rrn` VARCHAR(64) DEFAULT NULL,
            `signature` TEXT DEFAULT NULL,
            `raw_payload` MEDIUMTEXT DEFAULT NULL,
            `date_add` DATETIME NOT NULL,
            `date_upd` DATETIME NOT NULL,
            PRIMARY KEY (`id_ecconnect_order_meta`),
            UNIQUE KEY `uniq_order_shop` (`id_order`, `id_shop`),
            KEY `idx_shop` (`id_shop`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;';
        $ok = $ok && Db::getInstance()->execute($sql2);

        return $ok;
    }

    private function uninstallDb(): bool
    {
        $ok = true;

        $ok = $ok && Db::getInstance()
                       ->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ecconnect_customer_token`');
        $ok = $ok && Db::getInstance()
                       ->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ecconnect_order_meta`');

        return $ok;
    }

    public function saveOrderMeta(int $idOrder, array $meta): bool
    {
        return EcconnectOrderMeta::saveMeta($idOrder, $meta, $this->context->shop->id);
    }

    public function getOrderMeta(int $idOrder): array
    {
        return EcconnectOrderMeta::getMeta($idOrder, $this->context->shop->id);
    }

    public function hookDisplayBackOfficeHeader($params)
    {
        if (!isset($this->context) || !isset($this->context->controller)) {
            return;
        }

        $isLegacyOrderPage = (
            Tools::getValue('controller') === 'AdminOrders'
            && Tools::getIsset('vieworder')
            && (int)Tools::getValue('id_order') > 0
        );

        $reqUri = isset($_SERVER['REQUEST_URI']) ? (string)$_SERVER['REQUEST_URI'] : '';
        $isSfOrderPage = (
            (int)Tools::getValue('id_order') > 0
            && (strpos($reqUri, '/sell/orders/') !== false || strpos($reqUri, '/orders/') !== false)
        );

        if (!$isLegacyOrderPage && !$isSfOrderPage) {
            return;
        }

        $this->context->controller->addJS($this->_path . 'views/js/admin-capture.js');

        Media::addJsDef([
            'ecconnect_capture_ajax' => $this->context->link->getAdminLink(
                'AdminEcconnectCapture',
                true,
                [],
                ['ajax' => 1, 'action' => 'capture']
            ),
        ]);
    }

    public function hookDisplayAdminOrderMain($params)
    {
        $idOrder = (int)($params['id_order'] ?? 0);
        if ($idOrder <= 0) {
            return '';
        }

        $order = new Order($idOrder);
        if (!Validate::isLoadedObject($order)) {
            return '';
        }

        if ($order->module !== $this->name) {
            return '';
        }

        $targetStateId = 17;
        if ((int)$order->current_state !== $targetStateId) {
            return '';
        }

        $maxAmount = (float)$order->getOrdersTotalPaid();
        $this->context->smarty->assign([
            'ec_order_id' => $order->id,
            'ec_max_amount' => Tools::ps_round($maxAmount, 2),
            'ec_ajax_url' => $this->context->link->getAdminLink('AdminEcconnectCapture', true, [], [
                'ajax' => 1,
                'action' => 'capture',
            ]),
        ]);

        return $this->fetch('module:' . $this->name . '/views/templates/admin/capture_box.tpl');
    }

    /**
     * Повертає дані для запиту Capture
     *
     * @param Order $order
     * @param int $totalAmount Сума для списання (у копійках)
     *
     * @return array
     */
    public function getCaptureFormData(Order $order, int $totalAmount): array
    {
        $meta = EcconnectOrderMeta::getByOrderId((int)$order->id);

        $currency = new Currency((int)$order->id_currency);
        $currencyIso = $currency->iso_code;

        $availableCurrencies = [
            'UAH' => '980',
            'USD' => '840',
            'EUR' => '978',
        ];
        $currencyCode = $availableCurrencies[$currencyIso] ?? null;

        $orderIdForGateway = (int)$order->id_cart ?: (int)$order->id;

        return [
            'MerchantID' => Configuration::get('ECCONNECT_MERCHANT_ID'),
            'TerminalID' => Configuration::get('ECCONNECT_TERMINAL_ID'),
            'OrderID' => $orderIdForGateway,
            'Currency' => $currencyCode,
            'TotalAmount' => (int)round($order->total_paid * 100),
            'PurchaseTime' => $meta->purchase_time ?? '',
            'ApprovalCode' => $meta->approval_code ?? '',
            'RRN' => $meta->rrn ?? '',
            'PostauthorizationAmount' => $totalAmount,
            'Signature' => $meta->signature ?? '',
        ];
    }
}