<?php

class EcconnectResultModuleFrontController extends ModuleFrontController
{
    public function postProcess(){

        $TranCode = Tools::getValue('TranCode');
        $amount = Tools::getValue('TotalAmount') / 100;
        $cartID = Tools::getValue('OrderID');

        $this->context->cart = new Cart((int) $cartID);
        $cart = $this->context->cart;

        if ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active) {
            die('Cannot create order for this cart');
        }

        $customer = new Customer($cart->id_customer);

        if (!Validate::isLoadedObject($customer)) {
            die('No customer for this order');
        }

        if ($TranCode == '000') {

            $currency = new Currency((int)$cart->id_currency);
            

            if ($this->context->cart->OrderExists() == false){
               
                $this->module->validateOrder(
                (int)$cart->id,
                (int)Configuration::get('ECCONNECT_SUCCESS_STATUS_ID'),
                $amount,
                $this->module->displayName,
                null,
                null,
                (int)$currency->id,
                false,
                $customer->secure_key
                );

            }

            Tools::redirect(
                'index.php?controller=order-confirmation&id_cart=' . $this->context->cart->id .
                '&id_module=' . $this->module->id .
                '&id_order=' . $this->module->currentOrder .
                '&key=' . $customer->secure_key
            );

        } else {
			Tools::redirect('index.php?controller=order&step=1');
		}     
    }
}