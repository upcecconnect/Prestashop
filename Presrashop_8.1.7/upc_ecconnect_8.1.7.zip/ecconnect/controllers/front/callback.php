<?php
class EcconnectCallbackModuleFrontController extends ModuleFrontController {

    public function postProcess(){

        $MerchantID = Tools::getValue('MerchantID');
        $TerminalID = Tools::getValue('TerminalID');
        $OrderID = Tools::getValue('OrderID');
        $PurchaseTime = Tools::getValue('PurchaseTime');
        $TotalAmount = Tools::getValue('TotalAmount');
        $Currency = Tools::getValue('Currency');
        $XID = Tools::getValue('XID');
        $TranCode = Tools::getValue('TranCode');
        $ApprovalCode = Tools::getValue('ApprovalCode');

        $data = "$MerchantID;$TerminalID;$PurchaseTime;$OrderID;$XID;$Currency;$TotalAmount;;$TranCode;$ApprovalCode;";
                
        $cert = Configuration::get('ECCONNECT_SERVER_CERT');
        $signature_response = base64_decode(Tools::getValue('Signature'));

        $pubkeyid = openssl_get_publickey($cert);
        $ok = openssl_verify($data, $signature_response, $pubkeyid);

        if ($ok == 1){
            echo "accepted";
        }else if ($ok == 0){
            echo "failed";
        }else{
             echo "bad";
        }

            unset($pubkeyid);

            print
	        "MerchantID=".$MerchantID."\n".
	        "TerminalID=".$TerminalID."\n".
	        "OrderID=".$OrderID."\n".
	        "Currency=".$Currency."\n".
	        "TotalAmount=".$TotalAmount."\n".
	        "XID=".$XID."\n".
            "TranCode = " . $TranCode . "\n".
	        "PurchaseTime=".$PurchaseTime."\n\n".
	        "Response.action=approve\n".
	        "Response.reason=OK\n".
	        "Response.forwardUrl=\n";
    }
}