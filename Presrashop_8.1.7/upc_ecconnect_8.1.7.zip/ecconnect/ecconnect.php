<?php

if (!defined('_PS_VERSION_')){
    exit;
}

use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

class Ecconnect extends PaymentModule{

    private $postErrors = array();

    public function __construct(){

        $this->name = 'ecconnect';
        $this->tab = 'payments_gateways';
        $this->version = '1.0.0';
        $this->author = 'upc.ua';
        $this->currencies = true;
        $this->currencies_mode = 'checkbox';
        $this->bootstrap = true;
        $this->controllers = ['callback', 'result'];

        parent::__construct();

        $this->displayName = $this->l('ECommerceConnect');
        $this->description = $this->l('Accept online payments');

        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);

        if (!count(Currency::checkPaymentCurrencies($this->id))) {
            $this->warning = $this->l('No currency has been set for this module');
          }
    }

    public function install(){

        Configuration::updateValue('ECCONNECT_ACTIVE_MODE', true);

        $ow_status = Configuration::get('ECCONNECT_STATE_WAITING');

        if ($ow_status === false)
        {
        $orderState = new OrderState();
        }
        else {
        $orderState = new OrderState((int)$ow_status);
        }
		
		$orderState->name = array();
		
		foreach (Language::getLanguages() as $language) {
			if (Tools::strtolower($language['iso_code']) == 'uk') {
				$orderState->name[$language['id_lang']] = 'Очікування завершення оплати';
			} else if (Tools::strtolower($language['iso_code']) == 'ru') {
				$orderState->name[$language['id_lang']] = 'Ожидание завершения оплаты';
			} else {
                $orderState->name[$language['id_lang']] = 'Awaiting for payment';
            }
        }

        $orderState->send_email  = false;
        $orderState->color       = '#4169E1';
        $orderState->hidden      = false;
        $orderState->module_name = 'ecconnect';
        $orderState->delivery    = false;
        $orderState->logable     = false;
        $orderState->invoice     = false;
        $orderState->unremovable = true;
        $orderState->save();

        return parent::install() &&
            $this->registerHook('displayHeader') &&
            $this->registerHook('displayBackOfficeHeader') &&
            $this->registerHook('paymentOptions') &&
            $this->registerHook('actionOrderStatusPostUpdate') &&
            $this->registerHook('displayOrderConfirmation') &&
            $this->registerHook('displayPayment');
    }

    public function uninstall(){
        Configuration::deleteByName('ECCONNECT_GATEWAY_DOMAIN');
        Configuration::deleteByName('ECCONNECT_MERCHANT_ID');
        Configuration::deleteByName('ECCONNECT_TERMINAL_ID');
        Configuration::deleteByName('ECCONNECT_PRIVATE_KEY');
        Configuration::deleteByName('ECCONNECT_SERVER_CERT');
        Configuration::deleteByName('ECCONNECT_ACTIVE_MODE');
        Configuration::deleteByName('ECCONNECT_STATE_WAITING');
        Configuration::deleteByName('ECCONNECT_SUCCESS_STATUS_ID');

        return $this->unregisterHook('displayHeader') &&
        $this->unregisterHook('displayBackOfficeHeader') &&
        $this->unregisterHook('paymentOptions') &&
        $this->unregisterHook('actionOrderStatusPostUpdate') &&
        $this->unregisterHook('displayOrderConfirmation') &&
        $this->unregisterHook('displayPayment') &&
        parent::uninstall();
    }

    public function getContent(){

        if (((bool)Tools::isSubmit('submitEcconnectModule')) == true) {

            $this->postValidation();

            if (!sizeof($this->postErrors)) {
                $this->postProcess();
            } else {
                foreach ($this->postErrors as $error) {
                    $err .= $this->displayError($error);
                }
            }
        }

        return $err.$this->renderForm();

        //$this->context->smarty->assign('module_dir', $this->_path);

        //$output = $this->context->smarty->fetch($this->local_path.'views/templates/admin/configure.tpl');
        //return $output.$this->renderForm();
    }

    private function postValidation()
    {
        if (Tools::isSubmit('submitEcconnectModule')) {
            $payment_url = Tools::getValue('ECCONNECT_GATEWAY_DOMAIN');
            $merchant_id = Tools::getValue('ECCONNECT_MERCHANT_ID');
            $terminal_id = Tools::getValue('ECCONNECT_TERMINAL_ID');
            $private_key = Tools::getValue('ECCONNECT_PRIVATE_KEY');
            $server_cert = Tools::getValue('ECCONNECT_SERVER_CERT');

            if (empty($payment_url)) {
                $this->postErrors[] = $this->l('Payment URL is required');
            }
            if (empty($merchant_id)) {
                $this->postErrors[] = $this->l('Merchant ID is required');
            }
            if (empty($terminal_id)) {
                $this->postErrors[] = $this->l('Terminal ID is required');
            }
        }
    }

    protected function renderForm(){

        $helper = new HelperForm();

        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);

        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitEcconnectModule';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
            .'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFormValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );

        return $helper->generateForm(array($this->getConfigForm()));
    }

    protected function getConfigForm(){
        global $cookie;

        $options = [];

        foreach (OrderState::getOrderStates($cookie->id_lang) as $state){
            if (empty($state['module_name'])) {
                $options[] = ['status_id' => $state['id_order_state'], 'name' => $state['name'] . " [ID: $state[id_order_state]]"];
            }
        }

        return array(
            'form' => array(
                'legend' => array(
                'title' => $this->l('Settings'),
                'icon' => 'icon-cogs',
                ),
                'input'  => array(
                    array(
                      'type'    => 'switch',
                      'label'   => $this->l('Active'),
                      'name'    => 'ECCONNECT_ACTIVE_MODE',
                      'is_bool' => true,
                      'values'  => array(
                        array(
                            'id'    => 'active_on',
                            'value' => true,
                            'label' => $this->l('Enabled')
                        ),
                        array(
                            'id'    => 'active_off',
                            'value' => false,
                            'label' => $this->l('Disabled')
                        )
                      ),
                    ),
                    array(
                        'type' => 'text',
						'desc' => $this->l('TEST: https://ecg.test.upc.ua/go/pay || PROD: https://secure.upc.ua/go/pay'),
                        'label' => $this->l('Payment page'),
                        'name' => 'ECCONNECT_GATEWAY_DOMAIN',
                        'required' => true
                    ),
                    array(
						'required' => true,
                        'type' => 'text',
                        'desc' => $this->l('Merchant ID'),
                        'name' => 'ECCONNECT_MERCHANT_ID',
                        'label' => $this->l('Merchant ID'),
                        'required' => true
                    ),
                    array(
						'required' => true,
                        'type' => 'text',
                        'desc' => $this->l('Terminal ID'),
                        'name' => 'ECCONNECT_TERMINAL_ID',
                        'label' => $this->l('Terminal ID'),
                        'required' => true
                    ),
                    array(
						'required' => false,
                        'type' => 'text',
						'readonly' => true,
                        'desc' => $this->l(''),
                        'name' => 'ECCONNECT_PRIVATE_KEY',
                        'label' => $this->l('Private key'),
                    ),
					array(
                        'col' => 8,
                        'type' => 'file',
                        'desc' => $this->l('Upload merchant private key (.pem)'),
                        'name' => 'ECCONNECT_UPLOAD_KEY',
                        'label' => $this->l(''),
						),
                    array(
						'required' => false,
                        'type' => 'text',
						'readonly' => true,
					    'desc' => $this->l(''),
                        'name' => 'ECCONNECT_SERVER_CERT',
                        'label' => $this->l('Server cert'),
                    ),
					array(
                        'col' => 8,
                        'type' => 'file',
						'download_url' => true,
                        'desc' => $this->l('Upload server public certificate (.cert). You can get it from UPC'),
                        'name' => 'ECCONNECT_UPLOAD_CERT',
                        'label' => $this->l(''),
						),
					array(
                        'type' => 'select',
                        'prefix' => '<i class="icon icon-key"></i>',
                        'name' => 'ECCONNECT_SUCCESS_STATUS_ID',
                        'label' => $this->l('Status after success payment'),
                        'options' => array(
                            'query' => $options,
                            'id' => 'status_id',
                            'name' => 'name'
                        )
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                ),
            ),
        );
    }
    
    protected function getConfigFormValues(){
			
			if (isset($_FILES['ECCONNECT_UPLOAD_CERT']) && !empty($_FILES['ECCONNECT_UPLOAD_CERT']['tmp_name'])){	
							
				$upc_cert = Tools::file_get_contents($_FILES['ECCONNECT_UPLOAD_CERT']['tmp_name']);
				Configuration::updateValue('ECCONNECT_SERVER_CERT', $upc_cert);
            }
			
			if (isset($_FILES['ECCONNECT_UPLOAD_KEY']) && !empty($_FILES['ECCONNECT_UPLOAD_KEY']['tmp_name'])){	

				$upc_key = Tools::file_get_contents($_FILES['ECCONNECT_UPLOAD_KEY']['tmp_name']);
				Configuration::updateValue('ECCONNECT_PRIVATE_KEY', $upc_key);
            }  
     
        return array(
            'ECCONNECT_ACTIVE_MODE' => Configuration::get('ECCONNECT_ACTIVE_MODE', true),
            'ECCONNECT_GATEWAY_DOMAIN' => Configuration::get('ECCONNECT_GATEWAY_DOMAIN', null),
            'ECCONNECT_MERCHANT_ID' => Configuration::get('ECCONNECT_MERCHANT_ID', null),
            'ECCONNECT_TERMINAL_ID' => Configuration::get('ECCONNECT_TERMINAL_ID', null),
            'ECCONNECT_PRIVATE_KEY' => Configuration::get('ECCONNECT_PRIVATE_KEY', null),
            'ECCONNECT_SERVER_CERT' => Configuration::get('ECCONNECT_SERVER_CERT', null),
			'ECCONNECT_SUCCESS_STATUS_ID' => Configuration::get('ECCONNECT_SUCCESS_STATUS_ID', null),
        );
    }

    protected function postProcess(){
        $form_values = $this->getConfigFormValues();

        foreach (array_keys($form_values) as $key) {
            Configuration::updateValue($key, Tools::getValue($key));
        }
    }

    public function hookBackOfficeHeader(){
        if (Tools::getValue('module_name') == $this->name) {
            $this->context->controller->addJS($this->_path.'views/js/back.js');
            $this->context->controller->addCSS($this->_path.'views/css/back.css');
        }
    }

    public function displayHeader(){
        $this->context->controller->addJS($this->_path.'/views/js/front.js');
        $this->context->controller->addCSS($this->_path.'/views/css/front.css');
    }

    public function hookPaymentOptions($params){
        if (!$this->active) {
            return;
        }

        if (!$this->checkCurrency($params['cart'])){
            return;
        }
        
        $order = $params['cart'];
        $total_to_pay = $order->getOrderTotal();
        $curr = new Currency($order->id_currency);
		
		$PurchaseTime = date("ymdHis");
		$MerchantID = $this->l(Configuration::get('ECCONNECT_MERCHANT_ID'));
		$TerminalID = $this->l(Configuration::get('ECCONNECT_TERMINAL_ID'));
		$TotalAmount = number_format($total_to_pay, 2, '.', '')*100;
		$OrderID = $order->id;
		$Currency = $curr->iso_code_num;
		
		$data = "$MerchantID;$TerminalID;$PurchaseTime;$OrderID;$Currency;$TotalAmount;;";
		
		$pkeyid = openssl_get_privatekey($this->l(Configuration::get('ECCONNECT_PRIVATE_KEY'))); 
		openssl_sign($data, $signature, $pkeyid); 
		unset($pkeyid); 
		$b64sign = base64_encode($signature);

        $option = new PaymentOption();
        $option->setCallToActionText($this->l('Pay by ECommerceConnect'))
               ->setAction($this->l(trim(Configuration::get('ECCONNECT_GATEWAY_DOMAIN'))))
               ->setInputs([
                'Version' => [
                    'name' => 'Version',
                    'type' => 'hidden',
                    'value' => '1',
                ],
                'MerchantID' => [
                    'name' => 'MerchantID',
                    'type' => 'hidden',
                    'value' => $MerchantID,
                ],
                'TerminalID' => [
                    'name' => 'TerminalID',
                    'type' => 'hidden',
                    'value' => $TerminalID,
                ],
                'TotalAmount' => [
                    'name' => 'TotalAmount',
                    'type' => 'hidden',
                    'value' => $TotalAmount,
                ],
                'Currency' => [
                    'name' => 'Currency',
                    'type' => 'hidden',
                    'value' => $Currency,
                ],
                'OrderID' => [
                    'name' => 'OrderID',
                    'type' => 'hidden',
                    'value' => $OrderID,
                ],
                'PurchaseTime' => [
                    'name' => 'PurchaseTime',
                    'type' => 'hidden',
                    'value' => $PurchaseTime,
                ],
                'Locale' => [
                    'name' => 'Locale',
                    'type' => 'hidden',
                    'value' => $this->context->language->iso_code,
                ],
                'Signature' => [
                    'name' => 'Signature',
                    'type' => 'hidden',
                    'value' => $b64sign,
                ],
                'PurchaseDesc' => [
                    'name' => 'PurchaseDesc',
                    'type' => 'hidden',
                    'value' => 'Payment order',
                ]
            ]);

        return [$option];
    }

    public function checkCurrency($cart){
        $currency_order = new Currency($cart->id_currency);
        $currencies_module = $this->getCurrency($cart->id_currency);
        if (is_array($currencies_module)) {
            foreach ($currencies_module as $currency_module) {
                if ($currency_order->id == $currency_module['id_currency']) {
                    return true;
                }
            }
        }
        return false;
    }

    private function createConfirmationUrl(Cart $cart) {
        $customer = new Customer($cart->id_customer);
    
        return $this->context->shop->getBaseURL()
               . 'index.php?controller=order-confirmation&id_cart=' . $cart->id
               . '&id_module=' . $this->id
               . '&key=' . $customer->secure_key;
      }

   public function hookPaymentReturn($params){
       if (!$this->active) return;
       return $this->display(__FILE__, 'confirmation.tpl');
   }
}